export function changeEngine(newEngine) {
    return {
      type: 'CHANGE_ENGINE',
      engine: newEngine
    }
  }