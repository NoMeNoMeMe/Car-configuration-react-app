export function changeRimsPaint(newRimsPaint) {
    return {
      type: 'CHANGE_RIMS_PAINT',
      rims_paint: newRimsPaint
    }
  }