export function changeRimsSize(newRimsSize) {
    return {
      type: 'CHANGE_RIMS_SIZE',
      rims_size: newRimsSize
    }
  }