export function changePaint(newPaint) {
    return {
      type: 'CHANGE_PAINT',
      paint: newPaint
    }
  }