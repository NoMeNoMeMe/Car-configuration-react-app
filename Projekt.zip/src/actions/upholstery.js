export function changeUpholstery(newUpholstery) {
    return {
      type: 'CHANGE_UPHOLSTERY',
      upholstery: newUpholstery
    }
  }