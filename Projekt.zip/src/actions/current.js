export function changeCurrent(newCurrent) {
    return {
      type: 'CHANGE_CURRENT',
      current: newCurrent
    }
  }